<div>
   <p><?php echo $first_name.' '.$last_name;?></p>
   <p><?php echo $email;?></p>
   <p><?php echo $our_text;?></p>
</div>