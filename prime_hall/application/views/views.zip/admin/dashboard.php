
<div class="order_statistic_main_1">
    <form action="" method="post" id="order_statistic_form">
        <input type="text" autocomplete="off" name="date_statistic" class="date_statistic" placeholder="Date">

        <button type="button" class="search_statistic">Search</button>
    </form>
</div>
<div class="statistic_answer">

</div>
<script src="<?php echo base_url();?>assets/js/chart.js"></script>