<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />

    <title></title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="">
    <link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/backend/main.css');?>">
    <link rel="apple-touch-icon" href="">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <?php
    $language = $this->language_lib->switch_language();

    ?>

    <script type="text/javascript">
        lang = '<?php echo $language; ?>';
        base_url = '<?php echo base_url(); ?>';
        action = '<?php echo $this->router->class.'->'.$this->router->method; ?>';
    </script>

</head>