<div>
    <?php echo $offer_data['offer_'.$lang.''] ?>
</div>