<script src="<?php echo base_url();?>assets/js/ckeditor/ckeditor.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/backend/bottom.main.js"></script>
